export interface Auto {
    id: number
    brand: string
    price: number
  }